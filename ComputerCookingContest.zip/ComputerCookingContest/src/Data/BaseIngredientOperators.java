package Data;

public interface BaseIngredientOperators {
	public boolean equals(Object s);
	public Object getIngredient();
}
